import { Component, OnInit } from '@angular/core';
import { FormGroup, Validators, FormControl } from '@angular/forms';
import { Auth } from '../../models/auth.model';
import { AuthService } from '../../services/auth/auth.service';
import { Router } from '@angular/router';

import Swal from 'sweetalert2'

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  forma: FormGroup;

  remember: boolean = false;

  constructor(
    private _authService: AuthService,
    private _router: Router
  ) { }

  ngOnInit() {
    
    this.forma = new FormGroup({
      email: new FormControl( null, [ Validators.required ] ),
      password: new FormControl( null, [ Validators.required, Validators.minLength( 5 ) ] ),
      remember: new FormControl( false )
    });
    
    this.forma.patchValue({
      email: localStorage.getItem( 'email' ) || '',
      remember: localStorage.getItem( 'email' ) ? true : false
    });

    if ( this._authService.token ) {
      this._router.navigateByUrl( 'demo' );
    }

  }

  login() {

    if ( this.forma.invalid ) {
      return;
    }
    
    Swal.fire({
      allowOutsideClick: false,
      icon: 'info',
      text: 'authenticating...'
    });

    Swal.showLoading();

    let auth = new Auth( this.forma.value.email, this.forma.value.password );

    this._authService.login( auth, this.forma.value.remember )
      .subscribe( resp => {
        Swal.close();
        this._router.navigate([ '/directory' ]);
      }, () => {
        Swal.close();
        Swal.fire({
          icon: 'error',
          title: 'Error',
          text: 'Invalid Credentials'
        });
      })

  }

}
