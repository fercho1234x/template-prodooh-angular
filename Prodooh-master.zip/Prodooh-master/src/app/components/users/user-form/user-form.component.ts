import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { User } from 'src/app/models/user.model';
import { CompaniesService } from '../../../services/companies/companies.service';
import { FormGroup } from '@angular/forms';
import { Company } from '../../../models/companies.model';

@Component({
  selector: 'app-user-form',
  templateUrl: './user-form.component.html',
  styles: []
})
export class UserFormComponent implements OnInit {

  @Input() title:string;

  @Output() emitUserData:EventEmitter<User> = new EventEmitter<User>();
  
  forma: FormGroup;

  companies: Company[] = [];

  user: User;

  constructor( private _companiesService: CompaniesService ) {
    this._companiesService.getCompanies( 'all' )
      .subscribe( companies => {
        console.log( companies );
        this.companies = companies;
      })
  }

  ngOnInit() {
    this.user = new User(1, 2, 2, 'asdasda', 'asdasdasd', 'asdasdasd', 'dasdasd');
  }

  saveData() {
    this.emitUserData.emit( this.user );
  }

}
