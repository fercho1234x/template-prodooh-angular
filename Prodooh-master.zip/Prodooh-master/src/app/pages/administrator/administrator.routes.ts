import { RouterModule, Routes } from '@angular/router';
import { UserRegisterComponent } from './pages/users/user-register/user-register.component';
import { UserListComponent } from './pages/users/user-list/user-list.component';

const ADMINISTRATORROUTES: Routes = [
    { path: 'users/register', component: UserRegisterComponent },
    { path: 'users', component: UserListComponent },
    { path: '', redirectTo: '/administrator/users/register', pathMatch: 'full' },
];

export const ADMINISTRATOR_ROUTES = RouterModule.forChild( ADMINISTRATORROUTES );
