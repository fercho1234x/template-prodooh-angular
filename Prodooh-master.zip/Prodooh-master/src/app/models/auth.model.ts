export class Auth {
    constructor(
        public username:string,
        public password:string
    ) {}
}
