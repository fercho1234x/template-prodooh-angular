import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { AuthService } from './auth/auth.service';
import { APPCONFIG } from '../config/config';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class UsersService {

  constructor(
    private _http: HttpClient,
    private _authService: AuthService
  ) {}

  private getQuery( query:string, per_page = 30 ) {
    const URL = `${ APPCONFIG.endpoints.url_services }/${ query }?per_page=${ per_page }`;
    
    const headers = new HttpHeaders({
      'Authorization': `${ this._authService.token.token_type } ${ this._authService.token.access_token }`
    });
    
    return this._http.get( URL, { headers } );
  }

  getAllSuperAdministrators( per_page? ) {
    return this.getQuery( 'users/superadministrators', per_page )
      .pipe(
        map( (resp: any) => {
          return resp.data;
        })
      )
  }
}
